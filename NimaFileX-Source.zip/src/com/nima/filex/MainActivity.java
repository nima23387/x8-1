package com.nima.filex;

import android.app.*;
import android.os.Bundle;
import android.os.Environment;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.text.InputType;
import java.io.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends Activity {
    private LinearLayout root, top;
    private TextView pathView, statusView;
    private ListView list;
    private ArrayList<File> entries = new ArrayList<File>();
    private File current;
    private File clipboard;
    private boolean cutMode = false;
    private boolean showHidden = false;
    private ArrayAdapter<String> adapter;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        current = Environment.getExternalStorageDirectory();
        buildUi();
        refresh();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 23, 32));

        top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(12, 10, 12, 8);
        top.setBackgroundColor(Color.rgb(10, 15, 24));

        TextView title = new TextView(this);
        title.setText("NIMA  FILEX");
        title.setTextColor(Color.rgb(65, 210, 235));
        title.setTextSize(21);
        title.setTypeface(null, 1);
        top.addView(title);

        pathView = new TextView(this);
        pathView.setTextColor(Color.LTGRAY);
        pathView.setTextSize(11);
        top.addView(pathView);

        LinearLayout actions = new LinearLayout(this);
        String[] labels = {"بالا", "پوشه جدید", "Paste", "بیشتر"};
        for (int i=0;i<labels.length;i++) {
            final int n=i;
            Button btn = new Button(this);
            btn.setText(labels[i]);
            btn.setTextSize(11);
            btn.setPadding(2, 0, 2, 0);
            actions.addView(btn, new LinearLayout.LayoutParams(0, 44, 1));
            btn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if(n==0) goUp();
                    else if(n==1) createFolder();
                    else if(n==2) paste();
                    else showMore();
                }
            });
        }
        top.addView(actions);
        root.addView(top);

        list = new ListView(this);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setDividerHeight(1);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        statusView = new TextView(this);
        statusView.setTextColor(Color.rgb(65,210,235));
        statusView.setPadding(12, 6, 12, 6);
        statusView.setTextSize(11);
        root.addView(statusView);
        setContentView(root);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                File f=entries.get(pos);
                if(f.isDirectory()) { current=f; refresh(); }
                else if(f.getName().toLowerCase().endsWith(".zip")) showZipOptions(f);
                else showFileInfo(f);
            }
        });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                showFileMenu(entries.get(pos)); return true;
            }
        });
    }

    private void refresh() {
        if(current==null || !current.exists()) current=Environment.getExternalStorageDirectory();
        pathView.setText(current.getAbsolutePath());
        entries.clear();
        File[] fs=current.listFiles();
        if(fs!=null) {
            for(File f:fs) if(showHidden || !f.getName().startsWith(".")) entries.add(f);
        }
        Collections.sort(entries, new Comparator<File>() {
            public int compare(File a, File b) {
                if(a.isDirectory()!=b.isDirectory()) return a.isDirectory()?-1:1;
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        ArrayList<String> names=new ArrayList<String>();
        for(File f:entries) names.add((f.isDirectory()?"▣  ":"▤  ")+f.getName()+(f.isDirectory()?"/":""));
        adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, names);
        list.setAdapter(adapter);
        statusView.setText(entries.size()+" مورد    |    "+(showHidden?"فایل مخفی: روشن":"فایل مخفی: خاموش"));
    }

    private void goUp() {
        File parent=current.getParentFile();
        if(parent!=null && parent.canRead()) { current=parent; refresh(); }
    }

    private void createFolder() {
        final EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setHint("نام پوشه");
        new AlertDialog.Builder(this).setTitle("پوشه جدید").setView(input)
            .setPositiveButton("ساخت", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d,int w) {
                    String name=input.getText().toString().trim();
                    if(name.length()>0) {
                        File f=new File(current,name);
                        if(!f.mkdir()) toast("ساخت پوشه انجام نشد");
                        refresh();
                    }
                }
            }).setNegativeButton("لغو",null).show();
    }

    private void showMore() {
        final String[] opts={"نمایش فایل‌های مخفی","رفرش","اطلاعات حافظه"};
        new AlertDialog.Builder(this).setTitle("ابزارها").setItems(opts,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface d,int w){
                if(w==0){showHidden=!showHidden;refresh();}
                else if(w==1)refresh();
                else {
                    File s=Environment.getExternalStorageDirectory();
                    long total=s.getTotalSpace()/1024/1024, free=s.getFreeSpace()/1024/1024;
                    new AlertDialog.Builder(MainActivity.this).setMessage("حافظه مشترک\\nکل: "+total+" MB\\nآزاد: "+free+" MB").setPositiveButton("باشه",null).show();
                }
            }
        }).show();
    }

    private void showFileMenu(final File f) {
        final String[] opts={"باز کردن / اطلاعات","کپی","انتقال","تغییر نام","حذف","ساخت ZIP"};
        new AlertDialog.Builder(this).setTitle(f.getName()).setItems(opts,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface d,int w){
                if(w==0){if(f.isDirectory()){current=f;refresh();}else if(f.getName().toLowerCase().endsWith(".zip"))showZipOptions(f);else showFileInfo(f);}
                if(w==1||w==2){clipboard=f;cutMode=(w==2);toast(cutMode?"برای انتقال، Paste را بزن":"برای کپی، Paste را بزن");}
                if(w==3)rename(f);
                if(w==4)confirmDelete(f);
                if(w==5)zipFile(f);
            }
        }).show();
    }

    private void rename(final File f) {
        final EditText input=new EditText(this); input.setText(f.getName()); input.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("تغییر نام").setView(input)
            .setPositiveButton("ذخیره",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){
                String n=input.getText().toString().trim();
                if(n.length()>0 && !new File(f.getParentFile(),n).exists()) { if(!f.renameTo(new File(f.getParentFile(),n)))toast("تغییر نام ناموفق بود"); }
                refresh();
            }}).setNegativeButton("لغو",null).show();
    }

    private void confirmDelete(final File f) {
        new AlertDialog.Builder(this).setTitle("حذف").setMessage("«"+f.getName()+"» حذف شود؟")
            .setPositiveButton("حذف",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){
                if(!deleteTree(f))toast("حذف کامل انجام نشد"); refresh();
            }}).setNegativeButton("لغو",null).show();
    }

    private boolean deleteTree(File f) {
        if(f.isDirectory()){File[] a=f.listFiles();if(a!=null)for(File c:a)if(!deleteTree(c))return false;}
        return f.delete();
    }

    private void paste() {
        if(clipboard==null){toast("چیزی برای Paste انتخاب نشده");return;}
        try {
            File dest=new File(current,clipboard.getName());
            if(dest.exists()){toast("فایلی با این نام وجود دارد");return;}
            if(cutMode) {
                if(!clipboard.renameTo(dest)) copyTree(clipboard,dest);
                if(clipboard.exists()) deleteTree(clipboard);
            } else copyTree(clipboard,dest);
            clipboard=null; cutMode=false; refresh(); toast("انجام شد");
        } catch(Exception e){toast("خطا: "+e.getMessage());}
    }

    private void copyTree(File src,File dst)throws IOException {
        if(src.isDirectory()){
            if(!dst.mkdir())throw new IOException("ساخت پوشه مقصد ناموفق بود");
            File[] a=src.listFiles(); if(a!=null)for(File c:a)copyTree(c,new File(dst,c.getName()));
        } else {
            InputStream in=new FileInputStream(src); OutputStream out=new FileOutputStream(dst);
            byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n);
            in.close();out.close();
        }
    }

    private void zipFile(final File f) {
        final EditText input=new EditText(this);
        String name=f.getName(); if(name.lastIndexOf('.')>0)name=name.substring(0,name.lastIndexOf('.'));
        input.setText(name+".zip"); input.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("ساخت فایل ZIP").setView(input)
            .setPositiveButton("ساخت",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){
                String n=input.getText().toString().trim(); if(n.length()==0)return;
                try { File out=new File(current,n); ZipOutputStream z=new ZipOutputStream(new FileOutputStream(out)); zipAdd(f,f.getName(),z); z.close(); refresh(); toast("ZIP ساخته شد");}
                catch(Exception e){toast("خطای ZIP: "+e.getMessage());}
            }}).setNegativeButton("لغو",null).show();
    }

    private void zipAdd(File f,String name,ZipOutputStream z)throws IOException {
        if(f.isDirectory()){
            File[] a=f.listFiles(); if(a!=null)for(File c:a)zipAdd(c,name+"/"+c.getName(),z);
        } else {
            z.putNextEntry(new ZipEntry(name));
            FileInputStream in=new FileInputStream(f); byte[] b=new byte[8192]; int n;
            while((n=in.read(b))>0)z.write(b,0,n); in.close(); z.closeEntry();
        }
    }

    private void showZipOptions(final File f) {
        final String[] o={"استخراج همین‌جا","اطلاعات فایل"};
        new AlertDialog.Builder(this).setTitle(f.getName()).setItems(o,new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface d,int w){if(w==0)extractZip(f);else showFileInfo(f);}
        }).show();
    }

    private void extractZip(File f) {
        try {
            ZipInputStream in=new ZipInputStream(new FileInputStream(f)); ZipEntry e;
            while((e=in.getNextEntry())!=null) {
                File out=new File(current,e.getName());
                String rootPath=current.getCanonicalPath()+File.separator;
                if(!out.getCanonicalPath().startsWith(rootPath)) throw new IOException("مسیر نامعتبر داخل ZIP");
                if(e.isDirectory())out.mkdirs();
                else {
                    File p=out.getParentFile(); if(p!=null)p.mkdirs();
                    FileOutputStream os=new FileOutputStream(out); byte[] b=new byte[8192]; int n;
                    while((n=in.read(b))>0)os.write(b,0,n); os.close();
                }
                in.closeEntry();
            }
            in.close(); refresh(); toast("استخراج تمام شد");
        } catch(Exception e){toast("خطای استخراج: "+e.getMessage());}
    }

    private void showFileInfo(File f) {
        String type=f.isDirectory()?"پوشه":"فایل";
        String size=f.isDirectory()?"—":(f.length()/1024)+" KB";
        new AlertDialog.Builder(this).setTitle(f.getName())
            .setMessage(type+"\\nمسیر: "+f.getAbsolutePath()+"\\nحجم: "+size)
            .setPositiveButton("باشه",null).show();
    }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    public void onBackPressed() {
        File p=current.getParentFile();
        if(p!=null && p.canRead()) {current=p;refresh();}
        else super.onBackPressed();
    }
}
