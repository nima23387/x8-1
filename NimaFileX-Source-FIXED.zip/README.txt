Nima FileX - Android 2.3.7 / API 10
===================================
Package: com.nima.filex
Minimum Android: 2.3.3 (API 10)

Features in this first build:
- Browse folders and files on shared storage
- Create folders
- Copy, cut, paste, rename and delete
- Show/hide hidden files
- Create ZIP archives and extract ZIP archives

Notes:
- This first version supports ZIP, not RAR.
- It uses Android's normal shared-storage permissions; root is not required.
- On Android 2.3.7, the app can browse the SD card and shared storage.
- Build with the same legacy Android Ant/API 10 setup used for the Xperia X8 project:
    ant debug
- APK output: bin/NimaFileX-debug.apk
